from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import authenticate, login, logout
from .models import Student
# Create your views here.
def home(request):
    return render(request, 'home.html')

def about(request):
    return render(request, 'about.html')

def signup(request):
    if request.method == 'GET':
        form = UserCreationForm()
        return render(request, 'signup.html',{'form':form})
    else:
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
        else:
            return render(request, 'signup.html',{'form':form})

def loginacc(request):
    if request.method == 'GET':
        form = AuthenticationForm()
        return render(request, 'login.html',{'form':form})
    elif request.method == 'POST':
        user = authenticate(request,
         username = request.POST['username'],
         password=request.POST['password'])
        if user is None:
            form = AuthenticationForm()
            error = 'The Username & Password do not match'
            return render(request, 'login.html',{'form':form,'error':error})
        else:
            login(request, user)
            return redirect('home')
    
def logoutacc(request):
    logout(request)
    return redirect('home')

def list(request):
    students = Student.objects.all()
    return render(request, 'list.html', {'students':students})

def add(request):
    s = Student()
    if request.method == 'GET':
        return render(request, 'add.html')
    else:
        s.name = request.POST['name']
        s.branch = request.POST['branch']
        s.sem = request.POST['sem']
        s.email = request.POST['email']
        s.save()
        return redirect('home')