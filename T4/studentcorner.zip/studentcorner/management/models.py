from django.db import models

# Create your models here.
class Student(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField()
    branch = models.CharField()
    sem = models.IntegerField()
    email = models.EmailField()
    